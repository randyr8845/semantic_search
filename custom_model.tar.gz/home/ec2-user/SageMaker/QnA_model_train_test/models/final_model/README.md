---
tags:
- sentence-transformers
- sentence-similarity
- feature-extraction
- generated_from_trainer
- dataset_size:16406
- loss:MultipleNegativesRankingLoss
widget:
- source_sentence: What is (are) Problems with Smell ?
  sentences:
  - Problems with taste that occur with aging cannot be prevented. However you may
    be able to protect yourself against other causes of taste loss with these steps.
    - Prevent upper respiratory infections such as colds and the flu. Wash your hands
    frequently, especially during the winter months, and get a flu shot every year.   -
    Avoid Head Injuries. Always wear seatbelts when riding in a car and a helmet when
    bicycling.   - Avoid Exposure to Toxic Chemicals. Avoid contact with chemicals
    that might cause smell problems such as paints, insecticides, and solvents, or
    wear a respirator if you cannot avoid contact.   - Review Your Medications. If
    you are taking antibiotics or antihistamines or other medications and notice a
    change in your sense of taste, talk to your doctor. You may be able to adjust
    or change your medicine to one that will not cause a problem with taste. Do not
    stop taking your medications unless directed by your doctor.   - Dont Smoke. It
    can impair the sense of taste. For free help to quit smoking, visit Smokefree.gov  Prevent
    upper respiratory infections such as colds and the flu. Wash your hands frequently,
    especially during the winter months, and get a flu shot every year. Avoid Head
    Injuries. Always wear seatbelts when riding in a car and a helmet when bicycling.
    Avoid Exposure to Toxic Chemicals. Avoid contact with chemicals that might cause
    smell problems such as paints, insecticides, and solvents, or wear a respirator
    if you cannot avoid contact. Review Your Medications. If you are taking antibiotics
    or antihistamines or other medications and notice a change in your sense of taste,
    talk to your doctor. You may be able to adjust or change your medicine to one
    that will not cause a problem with taste. Do not stop taking your medications
    unless directed by your doctor. Dont Smoke. It can impair the sense of taste.
    For free help to quit smoking, visit Smokefree.gov
  - Smell is part of our chemical sensing system. Our sense of smell is the ability
    to detect odors in our environment through our nose, like the fragrance of flowers
    or the smell of baking bread. Smell is also the ability to detect food odors or
    aromas released in our mouths when we chew, which then flow from the roof of the
    throat region to the nose. Congestion blocks this flow and impacts our appreciation
    of the flavor of food.
  - Diabetes means your blood glucose (often called blood sugar) is too high. Your
    blood always has some glucose in it because your body needs glucose for energy
    to keep you going. But too much glucose in the blood isn't good for your health.
    Glucose comes from the food you eat and is also made in your liver and muscles.
    Your blood carries the glucose to all of the cells in your body. Insulin is a
    chemical (a hormone) made by the pancreas. The pancreas releases insulin into
    the blood. Insulin helps the glucose from food get into your cells. If your body
    does not make enough insulin or if the insulin doesn't work the way it should,
    glucose can't get into your cells. It stays in your blood instead. Your blood
    glucose level then gets too high, causing pre-diabetes or diabetes.
- source_sentence: How to diagnose High Blood Cholesterol ?
  sentences:
  - Heart failure is more common in - people who are 65 years old or older   - African-Americans  -
    people who are overweight   - people who have had a heart attack  - men. people
    who are 65 years old or older African-Americans people who are overweight people
    who have had a heart attack men. Aging can weaken the heart muscle. Older people
    also may have had diseases for many years that led to heart failure. African Americans
    are more likely to have heart failure than people of other races. They're also
    more likely to have symptoms at a younger age, have more hospital visits due to
    heart failure, and die from heart failure. Excess weight puts strain on the heart.
    Being overweight also increases your risk of heart disease and type 2 diabetes.
    These diseases can lead to heart failure. A history of a heart attack puts people
    at greater risk for heart failure. Men have a higher rate of heart failure than
    women.
  - Having a heart attack increases your chances of having another one. Therefore,
    it is very important that you and your family know how and when to seek medical
    attention. Talk to your doctor about making an emergency action plan, and discuss
    it with your family. The emergency action plan should include - warning signs
    or symptoms of a heart attack  - instructions for accessing emergency medical
    services in your community, including calling 9-1-1  - steps you can take while
    waiting for medical help to arrive, such as taking aspirin and nitroglycerin  -
    important information to take along with you to the hospital, such as a list of
    medications that you take or that you are allergic to, and name and number of
    whom you should contact if you go to the hospital. warning signs or symptoms of
    a heart attack instructions for accessing emergency medical services in your community,
    including calling 9-1-1 steps you can take while waiting for medical help to arrive,
    such as taking aspirin and nitroglycerin important information to take along with
    you to the hospital, such as a list of medications that you take or that you are
    allergic to, and name and number of whom you should contact if you go to the hospital.
  - The recommended blood test for checking your cholesterol levels is called a fasting
    lipoprotein profile. It will show your - total cholesterol  - low-density lipoprotein
    (LDL), or bad cholesterol -- the main source of cholesterol buildup and blockage
    in the arteries  - high-density lipoprotein (HDL), or good cholesterol that helps
    keep cholesterol from building up in your arteries  - triglycerides -- another
    form of fat in your blood. total cholesterol low-density lipoprotein (LDL), or
    bad cholesterol -- the main source of cholesterol buildup and blockage in the
    arteries high-density lipoprotein (HDL), or good cholesterol that helps keep cholesterol
    from building up in your arteries triglycerides -- another form of fat in your
    blood. You should not eat or drink anything except water and black coffee for
    9 to 12 hours before taking the test. If you can't have a lipoprotein profile
    done, a different blood test will tell you your total cholesterol and HDL (good)
    cholesterol levels. You do not have to fast before this test. If this test shows
    that your total cholesterol is 200 mg/dL or higher, or that your HDL (good) cholesterol
    is less than 40 mg/dL, you will need to have a lipoprotein profile done.
- source_sentence: What is (are) Ovarian, Fallopian Tube, and Primary Peritoneal Cancer
    ?
  sentences:
  - "Key Points\n                    - After anal cancer has been diagnosed, tests\
    \ are done to find out if cancer cells have spread within the anus or to other\
    \ parts of the body.     - There are three ways that cancer spreads in the body.\
    \    - Cancer may spread from where it began to other parts of the body.    -\
    \ The following stages are used for anal cancer:         - Stage 0 (Carcinoma\
    \ in Situ)     - Stage I     - Stage II     - Stage IIIA     - Stage IIIB    \
    \ - Stage IV\n                \n                \n                    After anal\
    \ cancer has been diagnosed, tests are done to find out if cancer cells have spread\
    \ within the anus or to other parts of the body.\n                    The process\
    \ used to find out if cancer has spread within the anus or to other parts of the\
    \ body is called staging. The information gathered from the staging process determines\
    \ the stage of the disease. It is important to know the stage in order to plan\
    \ treatment. The following tests may be used in the staging process:         \
    \ -   CT scan (CAT scan): A procedure that makes a series of detailed pictures\
    \ of areas inside the body, such as the abdomen or chest, taken from different\
    \ angles. The pictures are made by a computer linked to an x-ray machine. A dye\
    \ may be injected into a vein or swallowed to help the organs or tissues show\
    \ up more clearly. This procedure is also called computed tomography, computerized\
    \ tomography, or computerized axial tomography. For anal cancer, a CT scan of\
    \ the pelvis and abdomen may be done.    -   Chest x-ray : An x-ray of the organs\
    \ and bones inside the chest. An x-ray is a type of energy beam that can go through\
    \ the body and onto film, making a picture of areas inside the body.    -   MRI\
    \ (magnetic resonance imaging): A procedure that uses a magnet, radio waves, and\
    \ a computer to make a series of detailed pictures of areas inside the body. This\
    \ procedure is also called nuclear magnetic resonance imaging (NMRI).    -   PET\
    \ scan (positron emission tomography scan): A procedure to find malignant tumor\
    \ cells in the body. A small amount of radioactive glucose (sugar) is injected\
    \ into a vein. The PET scanner rotates around the body and makes a picture of\
    \ where glucose is being used in the body. Malignant tumor cells show up brighter\
    \ in the picture because they are more active and take up more glucose than normal\
    \ cells do.\n                \n                \n                    There are\
    \ three ways that cancer spreads in the body.\n                    Cancer can\
    \ spread through tissue, the lymph system, and the blood:         - Tissue. The\
    \ cancer spreads from where it began by growing into nearby areas.     - Lymph\
    \ system. The cancer spreads from where it began by getting into the lymph system.\
    \ The cancer travels through the lymph vessels to other parts of the body.   \
    \  - Blood. The cancer spreads from where it began by getting into the blood.\
    \ The cancer travels through the blood vessels to other parts of the body.\n \
    \               \n                \n                    Cancer may spread from\
    \ where it began to other parts of the body.\n                    When cancer\
    \ spreads to another part of the body, it is called metastasis. Cancer cells break\
    \ away from where they began (the primary tumor) and travel through the lymph\
    \ system or blood.         - Lymph system. The cancer gets into the lymph system,\
    \ travels through the lymph vessels, and forms a tumor (metastatic tumor) in another\
    \ part of the body.    - Blood. The cancer gets into the blood, travels through\
    \ the blood vessels, and forms a tumor (metastatic tumor) in another part of the\
    \ body.        The metastatic tumor is the same type of cancer as the primary\
    \ tumor. For example, if anal cancer spreads to the lung, the cancer cells in\
    \ the lung are actually anal cancer cells. The disease is metastatic anal cancer,\
    \ not lung cancer.\n                \n                \n                    The\
    \ following stages are used for anal cancer:\n                    Stage 0 (Carcinoma\
    \ in Situ)    In stage 0, abnormal cells are found in the innermost lining of\
    \ the anus. These abnormal cells may become cancer and spread into nearby normal\
    \ tissue. Stage 0 is also called carcinoma in situ.        Stage I    In stage\
    \ I, cancer has formed and the tumor is 2 centimeters or smaller.        Stage\
    \ II    In stage II, the tumor is larger than 2 centimeters.        Stage IIIA\
    \     In stage IIIA, the tumor may be any size and has spread to either:     \
    \       -  lymph nodes near the rectum; or      - nearby organs, such as the vagina,\
    \ urethra, and bladder.              Stage IIIB    In stage IIIB, the tumor may\
    \ be any size and has spread:            - to nearby organs and to lymph nodes\
    \ near the rectum; or     - to lymph nodes on one side of the pelvis and/or groin,\
    \ and may have spread to nearby organs; or     - to lymph nodes near the rectum\
    \ and in the groin, and/or to lymph nodes on both sides of the pelvis and/or groin,\
    \ and may have spread to nearby organs.              Stage IV    In stage IV,\
    \ the tumor may be any size and cancer may have spread to lymph nodes or nearby\
    \ organs and has spread to distant parts of the body."
  - "Key Points\n                    - Ovarian, fallopian tube, and primary peritoneal\
    \ cancers are diseases in which malignant (cancer) cells form in the ovaries,\
    \ fallopian tubes, or peritoneum.    - In the United States, ovarian cancer is\
    \ the fifth leading cause of cancer death in women.    -  Different factors increase\
    \ or decrease the risk of getting ovarian, fallopian tube, and primary peritoneal\
    \ cancer.\n                \n                \n                    Ovarian, fallopian\
    \ tube, and primary peritoneal cancers are diseases in which malignant (cancer)\
    \ cells form in the ovaries, fallopian tubes, or peritoneum.\n               \
    \     The ovaries are a pair of organs in the female reproductive system. They\
    \ are located in the pelvis, one on each side of the uterus (the hollow, pear-shaped\
    \ organ where a fetus grows). Each ovary is about the size and shape of an almond.\
    \ The ovaries produce eggs and female hormones (chemicals that control the way\
    \ certain cells or organs function).   The fallopian tubes are a pair of long,\
    \ slender tubes, one on each side of the uterus. Eggs pass from the ovaries, through\
    \ the fallopian tubes, to the uterus. Cancer sometimes begins at the end of the\
    \ fallopian tube near the ovary and spreads to the ovary.   The peritoneum is\
    \ the tissue that lines the abdominal wall and covers organs in the abdomen. Primary\
    \ peritoneal cancer is cancer that forms in the peritoneum and has not spread\
    \ there from another part of the body. Cancer sometimes begins in the peritoneum\
    \ and spreads to the ovary.     Ovarian epithelial cancer, fallopian tube cancer,\
    \ and primary peritoneal cancer form in the same type of tissue. Studies of screening\
    \ tests look at these cancers together.    See the following PDQ summaries for\
    \ more information about ovarian, fallopian tube, and primary peritoneal cancers:\
    \         -   Ovarian, Fallopian Tube, and Primary Peritoneal Cancer Prevention\
    \     -  Genetics of Breast and Gynecologic Cancers     -  Ovarian Epithelial,\
    \ Fallopian Tube, and Primary Peritoneal Cancer Treatment     -  Ovarian Germ\
    \ Cell Tumors Treatment     -  Ovarian Low Malignant Potential Tumors Treatment\n\
    \                \n                \n                    In the United States,\
    \ ovarian cancer is the fifth leading cause of cancer death in women.\n      \
    \              Ovarian cancer is also the leading cause of death from cancer of\
    \ the female reproductive system. Over the last 20 years, the number of new cases\
    \ of ovarian cancer has gone down slightly in white women and in black women.\
    \ Since 2005, the number of deaths from ovarian cancer also decreased slightly\
    \ in white and black women."
  - Older adults are more likely to have chronic health conditions such as diabetes
    and heart disease. Managing these conditions can complicate treatment and affect
    the time it takes to recover. Also, older people's bodies metabolize, or break
    down, drugs at a slower rate than younger people, and this can have an effect
    on the way medicines are tolerated. For instance, some older adults may not be
    able to tolerate high doses of chemotherapy (cancer-fighting drugs) and radiation
    that are used to treat cancer.
- source_sentence: What is the outlook for Anal Cancer ?
  sentences:
  - In most cases, your primary care doctor can diagnose psoriasis simply by examining
    your skin. If your doctor isn't sure if you have psoriasis, he or she may order
    a biopsy. This involves removing a small sample of skin and looking at it under
    a microscope.
  - Treatment depends on a number of factors, including the type of leukemia, the
    patient's age and general health, where leukemia cells have collected in the body,
    and whether the leukemia has been treated before. Certain features of the leukemia
    cells and the patient's symptoms also may determine treatment options.
  - 'Certain factors affect the prognosis (chance of recovery) and treatment options.
    The prognosis (chance of recovery) depends on the following:         - The size
    of the tumor.    -  Where the tumor is in the anus.    - Whether the cancer has
    spread to the lymph nodes.        The treatment options depend on the following:         -
    The stage of the cancer.    -  Where the tumor is in the anus.    - Whether the
    patient has human immunodeficiency virus (HIV).    - Whether cancer remains after
    initial treatment or has recurred.'
- source_sentence: What to do for Alzheimer's Caregiving ?
  sentences:
  - Even if the doctor removes all the cancer that can be seen at the time of the
    operation, many patients receive chemotherapy after surgery to kill any cancer
    cells that are left. Chemotherapy treatment after surgery -- to increase the chances
    of a cure -- is called adjuvant therapy. Researchers have found that patients
    who received adjuvant therapy usually survived longer and went for longer periods
    of time without a recurrence of colon cancer than patients treated with surgery
    alone. Patients age 70 and older benefited from adjuvant treatment as much as
    their younger counterparts. In fact, adjuvant therapy is equally as effective
    -- and no more toxic -- for patients 70 and older as it is for younger patients,
    provided the older patients have no other serious diseases. Adjuvant chemotherapy
    is standard treatment for patients whose cancer is operable and who are at high
    risk for a recurrence of the disease. Most cases of colon cancer occur in individuals
    age 65 and over. But studies have shown that older patients receive adjuvant chemotherapy
    less frequently than younger patients.
  - Most people with Alzheimers disease are cared for at home by family members. Within
    families, caregiving is provided most often by wives and husbands, followed by
    daughters. As Alzheimers disease gets worse, the person will need more and more
    care. Because of this, you will need more help. It's okay to seek help whenever
    you need it. Building a local support system is a key way to get help. This system
    might include a caregiver support group, the local chapter of the Alzheimer's
    Association, family, friends, and faith groups. To learn where to get help in
    your community, contact - the Alzheimers Disease Education and Referral (ADEAR)
    Center, 1-800-438-4380 or visit www.nia.nih.gov/alzheimers  - the Alzheimer's
    Association at 1-800-272-3900.  the Alzheimers Disease Education and Referral
    (ADEAR) Center, 1-800-438-4380 or visit www.nia.nih.gov/alzheimers the Alzheimer's
    Association at 1-800-272-3900. Various professional services can help with everyday
    care in the home of someone with Alzheimers disease. Medicare, Medicaid, and other
    health insurance plans may help pay for these services. Contact Eldercare Locator
    to find the services you need in your area by calling 1-800-677-1116 or visiting  www.eldercare.gov.
    Home Health Care Services Home health care agencies send a home health aide or
    nurse to your home to help you care for a person with Alzheimers. They may come
    for a few hours or stay for 24 hours and are paid by the hour. Some home health
    aides are better trained and supervised than others. Ask your doctor or other
    health care professional about good home health care services in your area. Get
    as much information as possible about a service before you sign an agreement.
    Also, ask for and check references Here are some questions to ask before signing
    a home health care agreement. - Is your service licensed and accredited?  - How
    much do your services cost?  - What is included and not included in your services?  -
    How many days a week and hours a day will an aide come to my home?   - How do
    you check the background and experience of your home health aides?   - How do
    you train your home health aides?   - What types of emergency care can you provide?   -
    Who do I contact if there is a problem?  Is your service licensed and accredited?
    How much do your services cost? What is included and not included in your services?
    How many days a week and hours a day will an aide come to my home? How do you
    check the background and experience of your home health aides? How do you train
    your home health aides? What types of emergency care can you provide? Who do I
    contact if there is a problem? For information about how to find home health care
    services, see Caring for a Person with Alzheimers Disease. Meal Services Meal
    services bring hot meals to the person's home or your home. The delivery staff
    does not feed the person. The person with Alzheimers disease must qualify for
    the service based on local guidelines. Some groups do not charge for their services.
    Others may charge a small fee. For information, call Eldercare Locator at 1-800-677-1116
    or go to  www.eldercare.gov. You may also contact Meals on Wheels at 1-888-998-6325.
    Adult Day Care Services Adult day care services provide a safe environment, activities,
    and staff who take care of the person with Alzheimers at their own facility. This
    provides a much-needed break for you. Many programs provide transportation between
    the persons home and the facility. Adult day care services generally charge by
    the hour. Most insurance plans do not cover these costs. To find adult day care
    services in your area, contact the National Adult Day Services Association at
    1-877-745-1440. Watch a video to learn more about the services provided at adult
    day care.  Respite Services Respite services provide short stays, from a few days
    to a few weeks, in a nursing home or other place for the person with Alzheimers
    disease. This care allows you to get a break or go on a vacation. Respite services
    charge by the number of days or weeks that services are provided. Medicare or
    Medicaid may cover the cost of up to 5 days in a row of respite care in an inpatient
    facility. Most private insurance plans do not cover these costs. To find respite
    services in your community, call the National Respite Locator Service at 1-800-773-5433
    (toll-free). Geriatric Care Managers Geriatric care managers visit your home to
    assess your needs and suggest and arrange home-care services. They charge by the
    hour. Most insurance plans don't cover these costs. To find a geriatric care manager,
    contact the National Association of Professional Geriatric Care Managers at 1-520-881-8008.
    Mental Health Professionals and Social Workers Mental health professionals and
    social workers help you deal with any stress you may be feeling. They help you
    understand feelings, such as anger, sadness, or feeling out of control. They can
    also help you make plans for unexpected or sudden events. Mental health professionals
    charge by the hour. Medicare, Medicaid, and some private health insurance plans
    may cover some of these costs. Ask your health insurance plan which mental health
    counselors and services it covers. Then check with your doctor, local family service
    agencies, and community mental health agencies for referrals to counselors.
  - 'Signs of colon cancer include blood in the stool or a change in bowel habits.
    These and other signs and symptoms may be caused by colon cancer or by other conditions.
    Check with your doctor if you have any of the following:         - A change in
    bowel habits.    -  Blood (either bright red or very dark) in the stool.    -  Diarrhea,
    constipation, or feeling that the bowel does not empty all the way.    - Stools
    that are narrower than usual.    - Frequent gas pains, bloating, fullness, or
    cramps.    - Weight loss for no known reason.    - Feeling very tired.    -  Vomiting.'
pipeline_tag: sentence-similarity
library_name: sentence-transformers
---

# SentenceTransformer

This is a [sentence-transformers](https://www.SBERT.net) model trained. It maps sentences & paragraphs to a 384-dimensional dense vector space and can be used for semantic textual similarity, semantic search, paraphrase mining, text classification, clustering, and more.

## Model Details

### Model Description
- **Model Type:** Sentence Transformer
<!-- - **Base model:** [Unknown](https://huggingface.co/unknown) -->
- **Maximum Sequence Length:** 384 tokens
- **Output Dimensionality:** 384 dimensions
- **Similarity Function:** Cosine Similarity
<!-- - **Training Dataset:** Unknown -->
<!-- - **Language:** Unknown -->
<!-- - **License:** Unknown -->

### Model Sources

- **Documentation:** [Sentence Transformers Documentation](https://sbert.net)
- **Repository:** [Sentence Transformers on GitHub](https://github.com/UKPLab/sentence-transformers)
- **Hugging Face:** [Sentence Transformers on Hugging Face](https://huggingface.co/models?library=sentence-transformers)

### Full Model Architecture

```
SentenceTransformer(
  (0): Transformer({'max_seq_length': 384, 'do_lower_case': False}) with Transformer model: BertModel 
  (1): Pooling({'word_embedding_dimension': 384, 'pooling_mode_cls_token': False, 'pooling_mode_mean_tokens': True, 'pooling_mode_max_tokens': False, 'pooling_mode_mean_sqrt_len_tokens': False, 'pooling_mode_weightedmean_tokens': False, 'pooling_mode_lasttoken': False, 'include_prompt': True})
  (2): Normalize()
)
```

## Usage

### Direct Usage (Sentence Transformers)

First install the Sentence Transformers library:

```bash
pip install -U sentence-transformers
```

Then you can load this model and run inference.
```python
from sentence_transformers import SentenceTransformer

# Download from the 🤗 Hub
model = SentenceTransformer("sentence_transformers_model_id")
# Run inference
sentences = [
    "What to do for Alzheimer's Caregiving ?",
    "Most people with Alzheimers disease are cared for at home by family members. Within families, caregiving is provided most often by wives and husbands, followed by daughters. As Alzheimers disease gets worse, the person will need more and more care. Because of this, you will need more help. It's okay to seek help whenever you need it. Building a local support system is a key way to get help. This system might include a caregiver support group, the local chapter of the Alzheimer's Association, family, friends, and faith groups. To learn where to get help in your community, contact - the Alzheimers Disease Education and Referral (ADEAR) Center, 1-800-438-4380 or visit www.nia.nih.gov/alzheimers  - the Alzheimer's Association at 1-800-272-3900.  the Alzheimers Disease Education and Referral (ADEAR) Center, 1-800-438-4380 or visit www.nia.nih.gov/alzheimers the Alzheimer's Association at 1-800-272-3900. Various professional services can help with everyday care in the home of someone with Alzheimers disease. Medicare, Medicaid, and other health insurance plans may help pay for these services. Contact Eldercare Locator to find the services you need in your area by calling 1-800-677-1116 or visiting  www.eldercare.gov. Home Health Care Services Home health care agencies send a home health aide or nurse to your home to help you care for a person with Alzheimers. They may come for a few hours or stay for 24 hours and are paid by the hour. Some home health aides are better trained and supervised than others. Ask your doctor or other health care professional about good home health care services in your area. Get as much information as possible about a service before you sign an agreement. Also, ask for and check references Here are some questions to ask before signing a home health care agreement. - Is your service licensed and accredited?  - How much do your services cost?  - What is included and not included in your services?  - How many days a week and hours a day will an aide come to my home?   - How do you check the background and experience of your home health aides?   - How do you train your home health aides?   - What types of emergency care can you provide?   - Who do I contact if there is a problem?  Is your service licensed and accredited? How much do your services cost? What is included and not included in your services? How many days a week and hours a day will an aide come to my home? How do you check the background and experience of your home health aides? How do you train your home health aides? What types of emergency care can you provide? Who do I contact if there is a problem? For information about how to find home health care services, see Caring for a Person with Alzheimers Disease. Meal Services Meal services bring hot meals to the person's home or your home. The delivery staff does not feed the person. The person with Alzheimers disease must qualify for the service based on local guidelines. Some groups do not charge for their services. Others may charge a small fee. For information, call Eldercare Locator at 1-800-677-1116 or go to  www.eldercare.gov. You may also contact Meals on Wheels at 1-888-998-6325. Adult Day Care Services Adult day care services provide a safe environment, activities, and staff who take care of the person with Alzheimers at their own facility. This provides a much-needed break for you. Many programs provide transportation between the persons home and the facility. Adult day care services generally charge by the hour. Most insurance plans do not cover these costs. To find adult day care services in your area, contact the National Adult Day Services Association at 1-877-745-1440. Watch a video to learn more about the services provided at adult day care.  Respite Services Respite services provide short stays, from a few days to a few weeks, in a nursing home or other place for the person with Alzheimers disease. This care allows you to get a break or go on a vacation. Respite services charge by the number of days or weeks that services are provided. Medicare or Medicaid may cover the cost of up to 5 days in a row of respite care in an inpatient facility. Most private insurance plans do not cover these costs. To find respite services in your community, call the National Respite Locator Service at 1-800-773-5433 (toll-free). Geriatric Care Managers Geriatric care managers visit your home to assess your needs and suggest and arrange home-care services. They charge by the hour. Most insurance plans don't cover these costs. To find a geriatric care manager, contact the National Association of Professional Geriatric Care Managers at 1-520-881-8008. Mental Health Professionals and Social Workers Mental health professionals and social workers help you deal with any stress you may be feeling. They help you understand feelings, such as anger, sadness, or feeling out of control. They can also help you make plans for unexpected or sudden events. Mental health professionals charge by the hour. Medicare, Medicaid, and some private health insurance plans may cover some of these costs. Ask your health insurance plan which mental health counselors and services it covers. Then check with your doctor, local family service agencies, and community mental health agencies for referrals to counselors.",
    'Signs of colon cancer include blood in the stool or a change in bowel habits. These and other signs and symptoms may be caused by colon cancer or by other conditions. Check with your doctor if you have any of the following:         - A change in bowel habits.    -  Blood (either bright red or very dark) in the stool.    -  Diarrhea, constipation, or feeling that the bowel does not empty all the way.    - Stools that are narrower than usual.    - Frequent gas pains, bloating, fullness, or cramps.    - Weight loss for no known reason.    - Feeling very tired.    -  Vomiting.',
]
embeddings = model.encode(sentences)
print(embeddings.shape)
# [3, 384]

# Get the similarity scores for the embeddings
similarities = model.similarity(embeddings, embeddings)
print(similarities.shape)
# [3, 3]
```

<!--
### Direct Usage (Transformers)

<details><summary>Click to see the direct usage in Transformers</summary>

</details>
-->

<!--
### Downstream Usage (Sentence Transformers)

You can finetune this model on your own dataset.

<details><summary>Click to expand</summary>

</details>
-->

<!--
### Out-of-Scope Use

*List how the model may foreseeably be misused and address what users ought not to do with the model.*
-->

<!--
## Bias, Risks and Limitations

*What are the known or foreseeable issues stemming from this model? You could also flag here known failure cases or weaknesses of the model.*
-->

<!--
### Recommendations

*What are recommendations with respect to the foreseeable issues? For example, filtering explicit content.*
-->

## Training Details

### Training Dataset

#### Unnamed Dataset

* Size: 16,406 training samples
* Columns: <code>anchor</code> and <code>positive</code>
* Approximate statistics based on the first 1000 samples:
  |         | anchor                                                                            | positive                                                                             |
  |:--------|:----------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
  | type    | string                                                                            | string                                                                               |
  | details | <ul><li>min: 6 tokens</li><li>mean: 12.31 tokens</li><li>max: 28 tokens</li></ul> | <ul><li>min: 13 tokens</li><li>mean: 224.99 tokens</li><li>max: 384 tokens</li></ul> |
* Samples:
  | anchor                                | positive                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
  |:--------------------------------------|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
  | <code>What is (are) Glaucoma ?</code> | <code>Glaucoma is a group of diseases that can damage the eye's optic nerve and result in vision loss and blindness. The most common form of the disease is open-angle glaucoma. With early treatment, you can often protect your eyes against serious vision loss. (Watch the video to learn more about glaucoma. To enlarge the video, click the brackets in the lower right-hand corner. To reduce the video, press the Escape (Esc) button on your keyboard.)  See this graphic for a quick overview of glaucoma, including how many people it affects, whos at risk, what to do if you have it, and how to learn more.  See a glossary of glaucoma terms.</code> |
  | <code>What is (are) Glaucoma ?</code> | <code>The optic nerve is a bundle of more than 1 million nerve fibers. It connects the retina to the brain.</code>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
  | <code>What is (are) Glaucoma ?</code> | <code>Open-angle glaucoma is the most common form of glaucoma. In the normal eye, the clear fluid leaves the anterior chamber at the open angle where the cornea and iris meet. When the fluid reaches the angle, it flows through a spongy meshwork, like a drain, and leaves the eye. Sometimes, when the fluid reaches the angle, it passes too slowly through the meshwork drain, causing the pressure inside the eye to build. If the pressure damages the optic nerve, open-angle glaucoma -- and vision loss -- may result.</code>                                                                                                                             |
* Loss: [<code>MultipleNegativesRankingLoss</code>](https://sbert.net/docs/package_reference/sentence_transformer/losses.html#multiplenegativesrankingloss) with these parameters:
  ```json
  {
      "scale": 20.0,
      "similarity_fct": "cos_sim"
  }
  ```

### Training Hyperparameters
#### Non-Default Hyperparameters

- `per_device_train_batch_size`: 16
- `per_device_eval_batch_size`: 16
- `num_train_epochs`: 5
- `warmup_ratio`: 0.1
- `fp16`: True

#### All Hyperparameters
<details><summary>Click to expand</summary>

- `overwrite_output_dir`: False
- `do_predict`: False
- `eval_strategy`: no
- `prediction_loss_only`: True
- `per_device_train_batch_size`: 16
- `per_device_eval_batch_size`: 16
- `per_gpu_train_batch_size`: None
- `per_gpu_eval_batch_size`: None
- `gradient_accumulation_steps`: 1
- `eval_accumulation_steps`: None
- `torch_empty_cache_steps`: None
- `learning_rate`: 5e-05
- `weight_decay`: 0.0
- `adam_beta1`: 0.9
- `adam_beta2`: 0.999
- `adam_epsilon`: 1e-08
- `max_grad_norm`: 1.0
- `num_train_epochs`: 5
- `max_steps`: -1
- `lr_scheduler_type`: linear
- `lr_scheduler_kwargs`: {}
- `warmup_ratio`: 0.1
- `warmup_steps`: 0
- `log_level`: passive
- `log_level_replica`: warning
- `log_on_each_node`: True
- `logging_nan_inf_filter`: True
- `save_safetensors`: True
- `save_on_each_node`: False
- `save_only_model`: False
- `restore_callback_states_from_checkpoint`: False
- `no_cuda`: False
- `use_cpu`: False
- `use_mps_device`: False
- `seed`: 42
- `data_seed`: None
- `jit_mode_eval`: False
- `use_ipex`: False
- `bf16`: False
- `fp16`: True
- `fp16_opt_level`: O1
- `half_precision_backend`: auto
- `bf16_full_eval`: False
- `fp16_full_eval`: False
- `tf32`: None
- `local_rank`: 0
- `ddp_backend`: None
- `tpu_num_cores`: None
- `tpu_metrics_debug`: False
- `debug`: []
- `dataloader_drop_last`: False
- `dataloader_num_workers`: 0
- `dataloader_prefetch_factor`: None
- `past_index`: -1
- `disable_tqdm`: False
- `remove_unused_columns`: True
- `label_names`: None
- `load_best_model_at_end`: False
- `ignore_data_skip`: False
- `fsdp`: []
- `fsdp_min_num_params`: 0
- `fsdp_config`: {'min_num_params': 0, 'xla': False, 'xla_fsdp_v2': False, 'xla_fsdp_grad_ckpt': False}
- `fsdp_transformer_layer_cls_to_wrap`: None
- `accelerator_config`: {'split_batches': False, 'dispatch_batches': None, 'even_batches': True, 'use_seedable_sampler': True, 'non_blocking': False, 'gradient_accumulation_kwargs': None}
- `deepspeed`: None
- `label_smoothing_factor`: 0.0
- `optim`: adamw_torch
- `optim_args`: None
- `adafactor`: False
- `group_by_length`: False
- `length_column_name`: length
- `ddp_find_unused_parameters`: None
- `ddp_bucket_cap_mb`: None
- `ddp_broadcast_buffers`: False
- `dataloader_pin_memory`: True
- `dataloader_persistent_workers`: False
- `skip_memory_metrics`: True
- `use_legacy_prediction_loop`: False
- `push_to_hub`: False
- `resume_from_checkpoint`: None
- `hub_model_id`: None
- `hub_strategy`: every_save
- `hub_private_repo`: None
- `hub_always_push`: False
- `gradient_checkpointing`: False
- `gradient_checkpointing_kwargs`: None
- `include_inputs_for_metrics`: False
- `include_for_metrics`: []
- `eval_do_concat_batches`: True
- `fp16_backend`: auto
- `push_to_hub_model_id`: None
- `push_to_hub_organization`: None
- `mp_parameters`: 
- `auto_find_batch_size`: False
- `full_determinism`: False
- `torchdynamo`: None
- `ray_scope`: last
- `ddp_timeout`: 1800
- `torch_compile`: False
- `torch_compile_backend`: None
- `torch_compile_mode`: None
- `dispatch_batches`: None
- `split_batches`: None
- `include_tokens_per_second`: False
- `include_num_input_tokens_seen`: False
- `neftune_noise_alpha`: None
- `optim_target_modules`: None
- `batch_eval_metrics`: False
- `eval_on_start`: False
- `use_liger_kernel`: False
- `eval_use_gather_object`: False
- `average_tokens_across_devices`: False
- `prompts`: None
- `batch_sampler`: batch_sampler
- `multi_dataset_batch_sampler`: proportional

</details>

### Training Logs
| Epoch  | Step | Training Loss |
|:------:|:----:|:-------------:|
| 0.4873 | 500  | 0.009         |
| 0.9747 | 1000 | 0.0111        |
| 1.4620 | 1500 | 0.008         |
| 1.9493 | 2000 | 0.0075        |
| 2.4366 | 2500 | 0.0057        |
| 2.9240 | 3000 | 0.008         |
| 3.4113 | 3500 | 0.0059        |
| 3.8986 | 4000 | 0.0073        |
| 4.3860 | 4500 | 0.0069        |
| 4.8733 | 5000 | 0.0081        |


### Framework Versions
- Python: 3.10.14
- Sentence Transformers: 3.4.1
- Transformers: 4.49.0
- PyTorch: 2.2.2
- Accelerate: 1.3.0
- Datasets: 3.3.1
- Tokenizers: 0.21.0

## Citation

### BibTeX

#### Sentence Transformers
```bibtex
@inproceedings{reimers-2019-sentence-bert,
    title = "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks",
    author = "Reimers, Nils and Gurevych, Iryna",
    booktitle = "Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing",
    month = "11",
    year = "2019",
    publisher = "Association for Computational Linguistics",
    url = "https://arxiv.org/abs/1908.10084",
}
```

#### MultipleNegativesRankingLoss
```bibtex
@misc{henderson2017efficient,
    title={Efficient Natural Language Response Suggestion for Smart Reply},
    author={Matthew Henderson and Rami Al-Rfou and Brian Strope and Yun-hsuan Sung and Laszlo Lukacs and Ruiqi Guo and Sanjiv Kumar and Balint Miklos and Ray Kurzweil},
    year={2017},
    eprint={1705.00652},
    archivePrefix={arXiv},
    primaryClass={cs.CL}
}
```

<!--
## Glossary

*Clearly define terms in order to be accessible across audiences.*
-->

<!--
## Model Card Authors

*Lists the people who create the model card, providing recognition and accountability for the detailed work that goes into its construction.*
-->

<!--
## Model Card Contact

*Provides a way for people who have updates to the Model Card, suggestions, or questions, to contact the Model Card authors.*
-->